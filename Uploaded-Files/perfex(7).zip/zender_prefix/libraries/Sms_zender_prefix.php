<?php
defined("BASEPATH") or exit("No direct script access allowed");

class Sms_zender_prefix extends App_sms
{
    public function __construct()
    {
        parent::__construct();

        $this->zender_prefix_key = $this->get_option("zender_prefix", "zender_prefix_key");
        $this->zender_prefix_service = $this->get_option("zender_prefix", "zender_prefix_service");
        $this->zender_prefix_whatsapp = $this->get_option("zender_prefix", "zender_prefix_whatsapp");
        $this->zender_prefix_device = $this->get_option("zender_prefix", "zender_prefix_device");
        $this->zender_prefix_gateway = $this->get_option("zender_prefix", "zender_prefix_gateway");
        $this->zender_prefix_sim = $this->get_option("zender_prefix", "zender_prefix_sim");

        $this->add_gateway("zender_prefix", [
            "name" => "zsms",
            "options" => [
                [
                    "name" => "zender_prefix_key",
                    "label" => "API Key (<a href=\"https://zsms.smartoffice.com.ph/dashboard/tools\" target=\"_blank\">Create API Key</a>)",
                    "info" => "
                    <p>Your API key, please make sure that everything is correct and required permissions are granted: <strong>send_sms</strong>, <strong>wa_send</strong></p>
                    <hr class=\"hr-10\" />"
                ],   
                [
                    "name" => "zender_prefix_service",
                    "field_type" => "radio",
                    "default_value" => 1,
                    "label" => "Sending Service",
                    "options" => [
                        ["label" => "SMS", "value" => 1],
                        ["label" => "WhatsApp", "value" => 2]
                    ],
                    "info" => "
                    <p>Select the sending service, please make sure that the api key has the following permissions: <strong>send_sms</strong>, <strong>wa_send</strong></p>
                    <hr class=\"hr-10\" />"
                ],      
                [
                    "name" => "zender_prefix_whatsapp",
                    "label" => "WhatsApp Account ID",
                    "info" => "
                    <p>For WhatsApp service only. WhatsApp account ID you want to use for sending.</p>
                    <hr class=\"hr-10\" />"
                ], 
                [
                    "name" => "zender_prefix_device",
                    "label" => "Device Unique ID",
                    "info" => "
                    <p>For SMS service only. Linked device unique ID, please only enter this field if you are sending using one of your devices.</p>
                    <hr class=\"hr-10\" />"
                ],        
                [
                    "name" => "zender_prefix_gateway",
                    "label" => "Gateway Unique ID",
                    "info" => "
                    <p>For SMS service only. Partner device unique ID or gateway ID, please only enter this field if you are sending using a partner device or third party gateway.</p>
                    <hr class=\"hr-10\" />"
                ],    
                [
                    "name" => "zender_prefix_sim",
                    "field_type" => "radio",
                    "default_value" => 1,
                    "label" => "SIM Slot",
                    "options" => [
                        ["label" => "SIM 1", "value" => 1],
                        ["label" => "SIM 2", "value" => 2]
                    ],
                    "info" => "
                    <p>For SMS service only. Select the sim slot you want to use for sending the messages. This is not used for partner devices and third party gateways.</p>
                    <hr class=\"hr-10\" />"
                ]
            ],
        ]);
    }

    public function send($number, $message)
    {
        if(empty($this->zender_prefix_service) || $this->zender_prefix_service < 2):
            if(!empty($this->zender_prefix_device)):
                $mode = "devices";
            else:
                $mode = "credits";
            endif;

            if($mode == "devices"):
                $form = [
                    "secret" => $this->zender_prefix_key,
                    "mode" => "devices",
                    "device" => $this->zender_prefix_device,
                    "phone" => $number,
                    "message" => $message,
                    "sim" => $this->zender_prefix_sim < 2 ? 1 : 2
                ];
            else:
                $form = [
                    "secret" => $this->zender_prefix_key,
                    "mode" => "credits",
                    "gateway" => $this->zender_prefix_gateway,
                    "phone" => $number,
                    "message" => $message
                ];
            endif;

            $apiurl = "https://zsms.smartoffice.com.ph/api/send/sms";
        else:
            $form = [
                "secret" => $this->zender_prefix_key,
                "account" => $this->zender_prefix_whatsapp,
                "type" => "text",
                "recipient" => $number,
                "message" => $message
            ];

            $apiurl = "https://zsms.smartoffice.com.ph/api/send/whatsapp";
        endif;

        try {
            $client = new GuzzleHttp\Client();

            $send = json_decode($client->post($apiurl, [
                "form_params" => $form,
                "allow_redirects" => true,
                "http_errors" => false
            ])->getBody()->getContents(), true);

            if($send["status"] == 200):
                log_activity("Sent via zsms to {$number} with message: {$message}");
                return true;
            else:
            
                $this->set_error("Message was not sent!<br>Message: {$send["message"]}");
                return false;
            endif;
        } catch(Exception $e){
            $this->set_error("Message was not sent!<br>Error: {$e->getMessage()}");
            return false;
            
        }
    }

}