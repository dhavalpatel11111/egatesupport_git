var select_arr = [];
var range_arr = [];
function phpData(params, select_type) {
    if (select_type == "select") {
        var answer = -1
        $.ajax(
            {
                type: "post",
                data: params,
                cache: false,
                async: false,
                url: 'php/test.php',
                dataType: "json",
                success: function (response) {
                    answer = response;
                    return response;
                },
                error: function (xhr, status, error) {
                }

            });

        return answer;
    } else {
        var answer = -1, answer_1, answer_2, answer_3, answer_4, arr = [];
        $.ajax(
            {
                type: "post",
                data: params,
                cache: false,
                async: false,
                url: 'php/test.php',
                dataType: "json",
                success: function (response) {
                    answer = response[0];
                    answer_1 = response[1];

                    if (undefined != response[2]) {
                        answer_2 = $.map(response[2], function (value, index) {
                            return [value];
                        });
                    }


                    if (undefined != response[3]) {
                        answer_3 = $.map(response[3], function (value, index) {
                            return [value];
                        });
                    }


                    answer_4 = response[2];
                    arr.push(answer, answer_1, answer_2, answer_3, answer_4);
                },
                error: function (response) {
                    var rest = response.responseText.substr(-32)
                    arr = rest;
                }
            });

        return arr;
    }

}
function drawSearchResult(rowsCount, arr) {
    var params_dates = [];
    for (var i = 0; i < rowsCount[0].length; i++) {
        params_dates.push(
            {"type": rowsCount[2][i], "value": arr[i], "name": rowsCount[0][i]}
        );
    }
    arr = [];
    var data = {
        "page": 1,
        "on_home": rowsCount[1],
        "table_name": rowsCount[3],
        "params": params_dates,
        "ordering": "none",
    };
    var select_page_data = phpData(data);
    var count = select_page_data[1] / rowsCount[1];
    if (count % 1 !== 1) {
        count = parseInt(count) + 1;
    }
    if (select_page_data[0] == undefined) {
        $(".pp").empty();
    } else {
        methods.drawBody(select_page_data, rowsCount);
        self.append(methods.pagination(select_page_data[1], rowsCount));
    }
    if (count <= 1) {
        $(".be_grid_last").remove();
        $(".be_grid_first").remove();
    }
    if (isNaN(count)) {
        $(".pagenationDiv").remove();
    }
}

(function ($) {
    'use strict';
    var methods;
    var grids_array = [];
    methods = {
        init: function (params) {
            var self = this, new_color, inputs_types, header_data, pagination_limit, dates_for_get = [], table_name;
            if (typeof params[0].color != 'undefined') new_color = params[0].color; else new_color = 'blue';
            if (typeof params[0].input_types != 'undefined') inputs_types = params[0].input_types; else inputs_types = ["text", "text", "text", "text", "text", "text", "text", "text", "text"];
            if (typeof params[0].header_data != 'undefined') header_data = params[0].header_data; else header_data = ["r_1", "r_2", "r_3", "r_4", "r_5", "r_6", "r_7", "r_8", "r_9"];
            if (typeof params[0].pagination_limit != 'undefined') pagination_limit = params[0].pagination_limit; else pagination_limit = 20;
            if (typeof params[0].table_name != 'undefined') table_name = params[0].table_name;
            for (var u = 0; u < inputs_types.length; u++) {
                if (inputs_types[u] == "combo") {
                    select_arr.push(header_data[u]);
                } else if (inputs_types[u] == "num_range") {
                    range_arr.push(header_data[u]);
                }
            }
            dates_for_get.push(header_data, pagination_limit, inputs_types, table_name, select_arr);
            grids_array.push(dates_for_get);
            // methods.change(self, new_color, inputs_types);
            methods.drawTable(self);
            methods.drawHeader(header_data,self);
            methods.drawInputs(header_data, inputs_types, dates_for_get, self);
            methods.drawTableBodyFirst(dates_for_get, self,grids_array);
            methods.drawPagination(self, dates_for_get,grids_array);
            methods.selectPage(self, dates_for_get,grids_array);
            methods.selectNext(self, dates_for_get,grids_array);
            methods.selectPrev(self, dates_for_get,grids_array);
            methods.search(self, dates_for_get,grids_array);
            methods.order(self, dates_for_get,grids_array);
            methods.selectLast(self, dates_for_get,grids_array);
            methods.selectFirst(self, dates_for_get,grids_array);


        },

        drawSearchResult: function (rowsCount, arr, self,that_grid) {
            var params_dates = [];
            for (var i = 0; i < rowsCount[0].length; i++) {
                params_dates.push(
                    {"type": rowsCount[2][i], "value": arr[i], "name": rowsCount[0][i]}
                );
            }


            var data = {
                "page": 1,
                "on_home": rowsCount[1],
                "table_name": rowsCount[3],
                "params": params_dates,
                "ordering": "none",
            };
            var select_page_data = phpData(data);
            var count = select_page_data[1] / rowsCount[1];

            if (count % 1 !== 1) {
                count = parseInt(count) + 1;
            }

            if (select_page_data[0] == undefined) {
                self.find(".pp"+that_grid).empty();
            } else {
                methods.drawBody(select_page_data, rowsCount,self,that_grid);
                self.append(methods.pagination(select_page_data[1], rowsCount,that_grid,self));
            }

            if (count <= 1) {
                self.find(".be_grid_last").remove();
                self.find(".be_grid_first").remove();
            }
            if (isNaN(count)) {
                self.find(".pagenationDiv").remove();
            }
        },

        getInputsVal: function () {
            $('.be_grid_input').keyup(function () {
                var arr = [];
                var dInput = this.value;
                $('.be_grid_input').each(function () {
                    arr.push($(this).val());
                });
            });
        },
        drawTable: function (self) {
            self.css({"display":"inline-block","margin-top":"30px"});
            var tableHtml = "<table class='be_grid_table' border='1' cellpadding='0' cellspacing='0'></table>";
            self.empty().append(tableHtml);
        },
        drawHeader: function (headerTitls,self) {
            var tbl = $(".be_grid_table").length;
            tbl = tbl - 1;
            var tableHeaderHtml = "";
            tableHeaderHtml = "<thead><tr>";
            for (var i = 0; i < headerTitls.length; i++) {
                tableHeaderHtml += "<th data_id='"+tbl+"' class='be_grid_header be_grid_header" + i + "' order=''>" + headerTitls[i] + "</th>";
            }
            tableHeaderHtml += "</tr>";

            self.find("table").append(tableHeaderHtml);
        },
        drawInputs: function (rowCounts, inputsType, rowsCount,self) {
            var tbl = $(".be_grid_table").length;
            tbl = tbl - 1;
            $(".be_grid_table").each(function (index,element) {
                $(this).addClass("be_grid_count"+index)
            })

            var inputs_html = "";
            inputs_html += "<tr>";
            var a = [];
            for (var i = 0; i < rowCounts.length; i++) {
                if (inputsType[i] == "img") {
                    $(".be_grid_header" + i).removeClass("be_grid_header");
                    inputs_html += "<th class='be_php_js_grid_head_input'><input data_id='"+tbl+"' class='be_grid_input' type='" + inputsType[i] + "' disabled></th>";
                } else if (inputsType[i] == "date_range") {
                    inputs_html += "<th class='be_php_js_grid_head_input'><input data_id='"+tbl+"' class='be_grid_input date_range' type='date' aaa='date_range' lolo='" + i + "'><input data_id='"+tbl+"' class='be_grid_input date_range' type='date' aaa='date_range' lolo='" + i + "'></th>";
                } else if (inputsType[i] == "num_range") {
                     var y = Math.floor((Math.random() * 10000) + 1);
                    inputs_html += "<th class='be_php_js_grid_head_input'><div style='width: 150px;height: 30px' class='" + inputsType[i] + "' data-idd='" + i + "' data-id='" + y + "' type='text' id='price' aaa='" + inputsType[i] + "'></div><div style='margin-left: 30%'><span  class='first_val" + y + "'>" +
                        "</span><span class='second_val" + y + "'></span></div><input data_id='"+y+"' type='hidden' class='be_grid_input range_first" + y + "' aaa='" + inputsType[i] + "' value=''><input data_idd='"+tbl+"' data_id='"+y+"' type='hidden' class='be_grid_input range_second" + y + "' aaa='" + inputsType[i] + "' value=''><div id = 'slider-" + y + "'></div></th>";
                } else if (inputsType[i] == "combo") {

                    var d = rowsCount[0][i];
                    var data = {
                        "on_home": rowsCount[4],
                        "table_name": rowsCount[3],
                    };
                    var select_dates = phpData(data, "select");
                    var a = [];
                    for (var select = 0; select < select_dates.length; select++) {
                        for (var o = 0; o < select_dates[select].length; o++) {
                            var option_element = select_dates[select][o][d];
                            inputs_html += "<option>" + option_element + "</option>";
                            a.push(option_element);
                        }
                    }
                    var unique = a.filter(function (itm, i, a) {
                        return i == a.indexOf(itm);
                    });

                    inputs_html += "<th class='be_php_js_grid_head_input'><select class='be_grid_input be_php_select " + inputsType[i] + " combo" + i + "' aaa='" + inputsType[i] + "' data_id='"+tbl+"' data-id='" + i + "'>";
                    inputs_html += "<option> </option>";

                    for (var o = 0; o < unique.length; o++) {
                        var option_element = unique[o];
                        inputs_html += "<option>" + option_element + "</option>"
                    }
                    inputs_html += "</select></th>";
                } else if (inputsType[i] == "link") {
                    inputs_html += "<th class='be_php_js_grid_head_input'><input data_id='"+tbl+"' class='be_grid_input " + inputsType[i] + "' type='" + "text" + "' aaa='" + inputsType[i] + "'></th>";
                } else {
                    inputs_html += "<th class='be_php_js_grid_head_input'><input data_id='"+tbl+"' class='be_grid_input " + inputsType[i] + "' type='" + inputsType[i] + "' aaa='" + inputsType[i] + "'></th>";
                }
            }
            inputs_html += "</tr></thead>";

            self.find("table").append(inputs_html);
            $(".be_grid_input").each(function () {
                if ($(this).attr("type") == "img") {
                    $(this).attr("disabled");
                }
            })
        },
        drawTableBodyFirst: function (rowsCount, self,gridarray) {
            var tbl = $(".be_grid_table").length;
            tbl = tbl - 1;
            rowsCount = gridarray[tbl]
            var params_dates = [];
            for (var i = 0; i < rowsCount[0].length; i++) {
                params_dates.push(
                    {"type": rowsCount[2][i], "value": "", "name": rowsCount[0][i]}
                );
            }
            var data = {
                "page": 1,
                "on_home": rowsCount[1],
                "table_name": rowsCount[3],
                "params": params_dates,
                "ordering": "none",
            };

            var gridDatesFromBase = phpData(data);
            self.find(".num_range").each(function () {
                var te = $(this).attr("data-id");
                var ted = $(this).attr("data-idd");
                var slider_range = $("#slider-" + te);
                var max = parseInt(gridDatesFromBase[2][ted]);
                var min = parseInt(gridDatesFromBase[3][ted]);
                slider_range.slider({
                    range: true,
                    min: min,
                    max: max,
                    values: [min, max],
                    slide: function (event, ui) {
                        // var ttt = $(this).prev().attr("data_id");
                        // rowsCount = gridarray[ttt];
                        // $(this).find("a").first().empty().append("<div class='be-termtip'><div class='be-termtip-inner'>" + $("#slider-" + te).slider("values", 0) + "</div></div>");
                        // $(this).find("a").last().empty().append("<div class='be-termtip'><div class='be-termtip-inner'>" + $("#slider-" + te).slider("values", 1) + "</div></div>");
                        // // $(this).find("a").first().find(".be-termtip").text(" ");
                        //
                        // self.find(".range_first" + te).val($("#slider-" + te).slider("values", 0));
                        // self.find(".range_second" + te).val($("#slider-" + te).slider("values", 1));
                        // var d = [];
                        // var arr = [];
                        //
                        // var search_array = search(self);
                        // self.find(".pagenationDiv").remove();
                        // // methods.drawSearchResult(rowsCount, search_array, self);
                        // //methods.drawSearchResult(rowsCount, search_array, self, ttt);
                        // methods.drawSearchResult(rowsCount, search_array, self, ttt);
                        // arr = [];
                        // methods.selectPage(self, rowsCount, gridarray);
                        // methods.selectLast(self, rowsCount,gridarray);
                        // methods.selectNext(self, rowsCount,gridarray);
                    },
                    change: function () {
                        // var ttt = $(this).prev().attr("data_id");
                        // rowsCount = gridarray[ttt];
                        // $(this).find("a").first().empty().append("<div class='be-termtip'><div class='be-termtip-inner'>" + $("#slider-" + te).slider("values", 0) + "</div></div>");
                        // $(this).find("a").last().empty().append("<div class='be-termtip'><div class='be-termtip-inner'>" + $("#slider-" + te).slider("values", 1) + "</div></div>");
                        // // $(this).find("a").first().find(".be-termtip").text(" ");
                        //
                        // self.find(".range_first" + te).val($("#slider-" + te).slider("values", 0));
                        // self.find(".range_second" + te).val($("#slider-" + te).slider("values", 1));
                        // var d = [];
                        // var arr = [];
                        //
                        // var search_array = search(self);
                        // self.find(".pagenationDiv").remove();
                        // // methods.drawSearchResult(rowsCount, search_array, self);
                        // //methods.drawSearchResult(rowsCount, search_array, self, ttt);
                        // methods.drawSearchResult(rowsCount, search_array, self, ttt);
                        // arr = [];
                        // methods.selectPage(self, rowsCount, gridarray);
                        // methods.selectLast(self, rowsCount,gridarray);
                        // methods.selectNext(self, rowsCount,gridarray);
                    },
                    stop: function (event, ui) {
                        var ttt = $(this).prev().attr("data_idd");
                        rowsCount = gridarray[ttt];
                        $(this).find("a").first().empty().append("<div class='be-termtip'><div class='be-termtip-inner'>" + $("#slider-" + te).slider("values", 0) + "</div></div>");
                        $(this).find("a").last().empty().append("<div class='be-termtip'><div class='be-termtip-inner'>" + $("#slider-" + te).slider("values", 1) + "</div></div>");
                        self.find(".range_first" + te).val($("#slider-" + te).slider("values", 0));
                        self.find(".range_second" + te).val($("#slider-" + te).slider("values", 1));
                        var d = [];
                        var arr = [];

                        var search_array = search(self);
                        self.find(".pagenationDiv").remove();
                        methods.drawSearchResult(rowsCount, search_array, self, ttt);
                        arr = [];
                        methods.selectPage(self, rowsCount, gridarray);
                        methods.selectLast(self, rowsCount,gridarray);
                        methods.selectNext(self, rowsCount,gridarray);
                    },
                });
            });

            if(gridDatesFromBase[0] != undefined && typeof gridDatesFromBase != "string"){
                methods.drawBody(gridDatesFromBase, rowsCount,self,"first");
            }else{

                if(gridDatesFromBase[0] == undefined){
                    var uu = "<div class='pp"+tbl+"'><span style='color: red;text-align: center;display: block'><strong>Empty Table</strong></span></div>";
                    self.append(uu)
                }

                if(typeof gridDatesFromBase == "string"){
                    var uu = "<div class='pp"+tbl+"'><span style='color: red;text-align: center;display: block'><strong>Error to connect Db,Wrong dates</strong></span></div>";
                    self.append(uu)
                }
            }

        },
        drawPagination: function (self, rowsCount,gridarray) {
            var tbl = $(".be_grid_table").length;
            tbl = tbl - 1;
            rowsCount = gridarray[tbl];
            var params_dates = [];
            for (var i = 0; i < rowsCount[0].length; i++) {
                params_dates.push(
                    {"type": rowsCount[2][i], "value": "", "name": rowsCount[0][i]}
                );
            }
            var data = {
                "page": 1,
                "on_home": 20,
                "table_name": rowsCount[3],
                "params": params_dates,
                "ordering": "none",
            };


            var count_from_base = phpData(data);

            if(count_from_base[0] != undefined && typeof count_from_base != "string"){
                self.append(methods.pagination(count_from_base[1], rowsCount,"first",self));
            }
        },
        selectPage: function (self, rowsCount,gridarray) {
            var arr = [];
            self.find(".pagenationDiv li").hover(function () {
                $(this).css("cursor", "pointer");
            });
            self.find(".be_grid_page").unbind("click");
            self.find(".be_grid_page").on("click", function () {
                var that_grid = $(this).attr("data_id");
                rowsCount = grids_array[that_grid];
                var params_dates = [];
                var d = [];
                var search_array = search(self);
                for (var i = 0; i < rowsCount[0].length; i++) {
                    params_dates.push(
                        {"type": rowsCount[2][i], "value": search_array[i], "name": rowsCount[0][i]}
                    );
                }


                var select = $(this).attr("pagination_value");
                var selectPageArray = [];
                var limit_end = (parseInt(select) * rowsCount[1]);
                var limit_start = parseInt(select);
                limit_end = rowsCount[1];

                var be_for_order = getOrder(self);
                var data = {
                    "page": limit_start,
                    "on_home": rowsCount[1],
                    "table_name": rowsCount[3],
                    "params": params_dates,
                    "ordering": be_for_order,
                };

                var select_page_data = phpData(data);
                methods.drawBody(select_page_data, rowsCount,self,that_grid);
                self.find(".be_grid_page").each(function () {
                    $(this).css("background-color", "")
                });

                $(this).css('background-color', 'background-color: #e0e0e0');
            });
            methods.selectLast(self, rowsCount,gridarray);
            methods.selectFirst(self, rowsCount,gridarray);
        },
        selectNext: function (self, rowsCount,gridarray) {
            self.find(".next").on("click", function () {
                var that_grid = $(this).attr("data_id");
                rowsCount = grids_array[that_grid]
                var arr = [];
                var d = [];
                var params_dates = [];
                var search_array = search(self);
                var new_page_start = $(this).prev().attr("pagination_value");
                var new_page_start = parseInt(new_page_start) + 1;
                var end = parseInt(new_page_start) + 7;
                var if_next = end - 1;
                var params_dates = [];
                for (var i = 0; i < rowsCount[0].length; i++) {
                    params_dates.push(
                        {"type": rowsCount[2][i], "value": search_array[i], "name": rowsCount[0][i]}
                    );
                }

                var be_for_order = getOrder(self);
                var data = {
                    "page": new_page_start,
                    "on_home": rowsCount[1],
                    "table_name": rowsCount[3],
                    "params": params_dates,
                    "ordering": be_for_order,
                };


                var select_page_data = phpData(data);

                var page_count = select_page_data[1] / rowsCount[1];
                if (page_count % 1 !== 0) {
                    page_count = parseInt(page_count) + 1;
                }
                page_count = parseInt(page_count);
                methods.drawBody(select_page_data, rowsCount,self,that_grid)

                var pagination_html = "";
                pagination_html += "<div class='pagenationDiv'>";
                pagination_html += "<ul>";
                pagination_html += "<li data_id='"+that_grid+"' class='be_grid_first be_php_js_grid_li' pagination_value='last'>First</li>";
                pagination_html += "<li data_id='"+that_grid+"' class='prev be_php_js_grid_li' pagination_value='prev'>  < </li>";


                for (var i = new_page_start; i < end - 1; i++) {
                    if (i <= page_count) {
                        if (i == new_page_start) {
                            pagination_html += "<li data_id='"+that_grid+"' style='background-color: #e0e0e0' class='be_grid_page be_php_js_grid_li' pagination_value='" + i + "'>" + i + "</li>";
                        } else {
                            pagination_html += "<li data_id='"+that_grid+"' class='be_grid_page be_php_js_grid_li' pagination_value='" + i + "'>" + i + "</li>";
                        }

                    }
                }
                end = end - 2;
                if (page_count != end) {
                    pagination_html += "<li data_id='"+that_grid+"' class='next be_php_js_grid_li' pagination_value='next'> > </li>";
                }
                pagination_html += "<li data_id='"+that_grid+"' class='be_grid_last be_php_js_grid_li' pagination_value='last'>Last</li>";
                pagination_html += "</ul>";
                pagination_html += "</div>";
                self.find(".pagenationDiv").remove();

                self.append(pagination_html);
                if (parseInt(self.find(".be_grid_page").last().attr("pagination_value")) + 1 != if_next) {
                    self.find(".next").remove();
                }
                methods.selectPage(self, rowsCount,gridarray);
                methods.selectNext(self, rowsCount,gridarray);
                methods.selectPrev(self, rowsCount,gridarray);
            })
        },
        selectPrev: function (self, rowsCount,gridarray) {
            self.find(".prev").unbind("click");
            self.find(".prev").on("click", function () {
                var that_grid = $(this).attr("data_id");
                rowsCount = gridarray[that_grid];
                var new_page_start = $(this).next().attr("pagination_value");
                new_page_start = parseInt(new_page_start);
                var stert = new_page_start - 6;
                var arr = [];
                var d = [];
                var params_dates = [];
                var search_array = search(self);
                for (var i = 0; i < rowsCount[0].length; i++) {
                    params_dates.push(
                        {"type": rowsCount[2][i], "value":search_array[i], "name": rowsCount[0][i]}
                    );
                }


                var be_for_order = getOrder(self);
                var data = {
                    "page": stert,
                    "on_home": rowsCount[1],
                    "table_name": rowsCount[3],
                    "params": params_dates,
                    "ordering": be_for_order,
                };
                var select_page_data = phpData(data);
                methods.drawBody(select_page_data, rowsCount,self,that_grid)
                var pagination_html = "";
                pagination_html += "<div class='pagenationDiv'>";
                pagination_html += "<ul>";
                pagination_html += "<li data_id='"+that_grid+"' class='be_grid_first be_php_js_grid_li' pagination_value='last'>First</li>";
                pagination_html += "<li data_id='"+that_grid+"' class='prev be_php_js_grid_li' pagination_value='prev'>  < </li>";
                for (var i = stert; i < new_page_start; i++) {
                    if (i == new_page_start) {
                        pagination_html += "<li data_id='"+that_grid+"' class='next be_php_js_grid_li' pagination_value='next'>  > </li>";
                    } else {

                        if (i == stert) {
                            pagination_html += "<li data_id='"+that_grid+"' style='background-color:#e0e0e0' class='be_grid_page be_php_js_grid_li' pagination_value='" + i + "'>" + i + "</li>";
                        } else {
                            pagination_html += "<li data_id='"+that_grid+"' class='be_grid_page be_php_js_grid_li' pagination_value='" + i + "'>" + i + "</li>";
                        }


                    }
                }
                pagination_html += "<li data_id='"+that_grid+"' class='next be_php_js_grid_li' pagination_value='next'>  > </li>";
                pagination_html += "<li data_id='"+that_grid+"' class='be_grid_last be_php_js_grid_li' pagination_value='last'>Last</li>";
                pagination_html += "</ul>";
                pagination_html += "</div>";
                self.find(".pagenationDiv").remove();
                self.append(pagination_html);
                self.find('.be_grid_page').each(function () {
                    if ($(this).attr("pagination_value") == 1) {
                        self.find(".prev").remove();
                    }
                });
                methods.selectPage(self, rowsCount, gridarray);
                methods.selectNext(self, rowsCount, gridarray);
                methods.selectPrev(self, rowsCount, gridarray);
                methods.selectLast(self, rowsCount, gridarray);
                methods.selectFirst(self, rowsCount, gridarray);

            })
        },
        search: function (self, rowsCount, gridarray) {
            self.find('.be_grid_input').change(function () {
                var that_grid = $(this).attr("data_id");
                rowsCount = gridarray[that_grid];
                var d = [];
                var search_array = search(self);
                self.find(".pagenationDiv").remove();
                methods.drawSearchResult(rowsCount, search_array, self,that_grid);
            });

            self.find('.be_grid_input').unbind("keyup");
            self.find('.be_grid_input').keyup(function () {
                var that_grid = $(this).attr("data_id");
                rowsCount = gridarray[that_grid];
                var search_array = search(self);
                var d = [];
                self.find(".pagenationDiv").remove();
                methods.drawSearchResult(rowsCount, search_array, self,that_grid);
            });
        },
        order: function (self, rowsCount, gridarray) {
            self.find(".be_grid_header").hover(function () {
                $(this).css("cursor", "pointer");
            });
            self.find(".be_grid_header").on("click", function () {
                var that_grid = $(this).attr("data_id");
                rowsCount = gridarray[that_grid];
                self.find(".be_grid_header").each(function () {
                    $(this).css("background-image",'url(' + 'img/sort-arrows.gif' + ')')
                });
                self.find(".be_grid_page").each(function () {
                    if ($(this).attr("pagination_value") == 1) {
                        $(this).css('background-color', '#c0c0c0');
                    } else {
                        $(this).css("background-color", "")
                    }
                });

                if ($(this).attr("order") == "") {
                    $(this).attr("order", "ASC");
                    $(this).css("background-image",'url(' + 'img/asc.gif' + ')');
                }else if($(this).attr("order") == "ASC"){
                    $(this).attr("order", "DESC");
                    $(this).css("background-image",'url(' + 'img/desc.gif' + ')');
                }else if($(this).attr("order") == "DESC"){
                    $(this).attr("order","");
                    $(this).css("background-image",'url(' + 'img/sort-arrows.gif' + ')')
                }
                self.find(".be_grid_header").not(this).attr("order", "");
                var arr = [];
                var params_dates = [];
                var order ;
                var order_array = [];
                for (var t = 0; t < arr.length; t++) {
                    order_array.push(
                        {"name": arr[t][1], "order": arr[t][0]}
                    );
                }
                var params_dates = [];
                var d = [];
                var search_array = search(self);
                for (var i = 0; i < rowsCount[0].length; i++) {
                    params_dates.push(
                        {"type": rowsCount[2][i], "value": search_array[i], "name": rowsCount[0][i]}
                    );
                }

                if(arr[0][0] == ""){
                    order = "none";
                }else{
                    order = order_array;
                }
                var data = {
                    "page": 1,
                    "on_home": rowsCount[1],
                    "table_name": rowsCount[3],
                    "params": params_dates,
                    "ordering": order,
                };
                var select_page_data = phpData(data);
                self.find(".pagenationDiv").remove();
                methods.drawBody(select_page_data, rowsCount,self,that_grid);
                self.append(methods.pagination(select_page_data[1], rowsCount,that_grid,self));

                methods.selectPage(self, rowsCount, gridarray);
                methods.selectNext(self, rowsCount, gridarray);
                methods.selectPrev(self, rowsCount, gridarray);
                methods.selectLast(self, rowsCount, gridarray);
                methods.selectFirst(self, rowsCount, gridarray);


            })
        },
        pagination: function (count, rowsCount, pType,self) {
            if(pType == "first"){
                var tbl = $(".be_grid_table").length;
                tbl = tbl - 1;
            }else{
                tbl = pType;
            }
            var page_count = count / rowsCount[1];
            if (page_count % 1 !== 0) {
                page_count = parseInt(page_count) + 1;
            }
            page_count = parseInt(page_count);
            var pagination_html = "";
            pagination_html += "<div class='pagenationDiv'>";
            pagination_html += "<ul>";
            pagination_html += "<li data_id='"+tbl+"' class='be_grid_first be_php_js_grid_li' pagination_value='last'>First</li>";
            if (page_count < 6) {
                var a = $.parseHTML(pagination_html);
                $(a).find(".be_grid_first").remove();
                for (var i = 0; i < page_count; i++) {
                    pagination_html += "<li data_id='"+tbl+"' class='be_grid_page be_php_js_grid_li' pagination_value='" + (i + 1) + "'>" + (i + 1) + "</li>";
                }
            } else {
                for (var i = 0; i < 7; i++) {
                    if (i == 6) {
                        pagination_html += "<li data_id='"+tbl+"' class='next be_php_js_grid_li' pagination_value='next'>  > </li>";
                    } else if (i == 0) {
                        if (pType == "first") {
                            pagination_html += "<li data_id='"+tbl+"' style='background-color: #e0e0e0' class='be_grid_page selected be_php_js_grid_li' pagination_value='" + (i + 1) + "'>" + (i + 1) + "</li>";
                        } else {
                            if (i == 0) {
                                pagination_html += "<li data_id='"+tbl+"' style='background-color: #e0e0e0' class='be_grid_page selected be_php_js_grid_li' pagination_value='" + (i + 1) + "'>" + (i + 1) + "</li>";
                            } else {
                                pagination_html += "<li data_id='"+tbl+"' class='be_grid_page selected be_php_js_grid_li' pagination_value='" + (i + 1) + "'>" + (i + 1) + "</li>";
                            }
                        }
                    } else {
                        pagination_html += "<li data_id='"+tbl+"' class='be_grid_page be_php_js_grid_li' pagination_value='" + (i + 1) + "'>" + (i + 1) + "</li>";
                    }
                }
            }
            pagination_html += "<li data_id='"+tbl+"' class='be_grid_last be_php_js_grid_li' pagination_value='last'>Last</li>";
            pagination_html += "</ul>";
            pagination_html += "</div>";
            if (page_count == 0) {
                var a = $.parseHTML(pagination_html);
                pagination_html = "";
            }
            return pagination_html;
        },
        drawBody: function (gridDatesFromBase, rowsCount,self,then_drwa) {
            if("first" == then_drwa){
                var lolo = $(".be_grid_table").length
                lolo = lolo - 1;
            }else{
                var toto = then_drwa;
                lolo = toto;
            }
            var gridFirstDatesHtml = "";
            for (var t = 0; t < gridDatesFromBase[0].length; t++) {
                gridFirstDatesHtml += "<tr class='pp"+lolo+"'>";
                for (var u = 0; u < rowsCount[0].length; u++) {
                    var d = rowsCount[0][u];
                    if (rowsCount[2][u] == "img") {
                        gridFirstDatesHtml += "<td class='be_php_js_grid_td'><img class='be_php_js_img' src='img/" + gridDatesFromBase[0][t][d] + "'></td>";
                    } else if (rowsCount[2][u] == "link") {
                        gridFirstDatesHtml += "<td class='be_php_js_grid_td'><a class='be_php_js_grid' href='" + gridDatesFromBase[0][t][d] + "'>" + gridDatesFromBase[0][t][d] + "</a></td>";
                    } else {
                        gridFirstDatesHtml += "<td class='be_php_js_grid_td'>" + gridDatesFromBase[0][t][d] + "</td>";
                    }
                }
                gridFirstDatesHtml += "</tr>";
            }
            if(then_drwa == "first"){
                self.find(".pp").remove();
                self.find(".be_grid_table").append(gridFirstDatesHtml);
            }else{
                self.find(".pp"+then_drwa).remove();
                self.find(".be_grid_count"+then_drwa).append(gridFirstDatesHtml);
            }


        },
        selectLast: function (self, rowsCount,gridarray) {
            self.find(".be_grid_last").unbind("click");
            self.find(".be_grid_last").on("click", function () {
                var that_grid = $(this).attr("data_id");
                rowsCount = gridarray[that_grid];
                var arr = [];
                var d = [];
                var params_dates = [];
                var search_array = search(self);

                for (var i = 0; i < rowsCount[0].length; i++) {
                    params_dates.push(
                        {"type": rowsCount[2][i], "value": search_array[i], "name": rowsCount[0][i]}
                    );
                }


                var be_for_order = getOrder(self);

                var data = {
                    "page": 1,
                    "on_home": rowsCount[1],
                    "table_name": rowsCount[3],
                    "params": params_dates,
                    "ordering": "none"
                };

                var select_page_data = phpData(data);
                var last_page = select_page_data[1] / rowsCount[1];
                if (last_page % 1 !== 0) {
                    last_page = parseInt(last_page) + 1;
                }

                var data = {
                    "page": last_page,
                    "on_home": rowsCount[1],
                    "table_name": rowsCount[3],
                    "params": params_dates,
                    "ordering": be_for_order
                };

                var select_page_data = phpData(data);
                methods.drawBody(select_page_data, rowsCount,self,that_grid);
                var start = last_page - 6;
                var for_color = last_page - 1;
                var pagination_html = "";
                pagination_html += "<div class='pagenationDiv'>";
                pagination_html += "<ul>";
                pagination_html += "<li data_id='"+that_grid+"' class='be_grid_first be_php_js_grid_li' pagination_value='last'>First</li>";
                if (start < 0) {
                    start = 0;
                } else {
                    pagination_html += "<li data_id='"+that_grid+"' class='prev be_php_js_grid_li' pagination_value='prev'>  < </li>";
                }

                for (var i = start; i < last_page; i++) {
                    if (i == for_color) {
                        pagination_html += "<li data_id='"+that_grid+"' style='background-color: #e0e0e0' class='be_grid_page be_php_js_grid_li' pagination_value='" + (i + 1) + "'>" + (i + 1) + "</li>";
                    } else {
                        pagination_html += "<li data_id='"+that_grid+"' class='be_grid_page be_php_js_grid_li' pagination_value='" + (i + 1) + "'>" + (i + 1) + "</li>";
                    }

                }
                pagination_html += "<li data_id='"+that_grid+"' class='be_grid_last be_php_js_grid_li' pagination_value='last'>Last</li>";
                pagination_html += "</ul>";
                pagination_html += "</div>";
                self.find(".pagenationDiv").remove();
                self.append(pagination_html);

                methods.selectPage(self, rowsCount, gridarray);
                methods.selectNext(self, rowsCount, gridarray);
                methods.selectPrev(self, rowsCount, gridarray);
                methods.selectFirst(self, rowsCount, gridarray);
            })
        },
        selectFirst: function (self, rowsCount, gridarray) {
            self.find(".be_grid_first").unbind("click");
            self.find(".be_grid_first").on("click", function () {
                var that_grid = $(this).attr("data_id");
                var arr = [];
                var params_dates = [];
                var d = [];
                var search_array = search(self);
                for (var i = 0; i < rowsCount[0].length; i++) {
                    params_dates.push(
                        {"type": rowsCount[2][i], "value": search_array[i], "name": rowsCount[0][i]}
                    );
                }

                var be_for_order = getOrder(self);
                var data = {
                    "page": 1,
                    "on_home": rowsCount[1],
                    "table_name": rowsCount[3],
                    "params": params_dates,
                    "ordering": be_for_order,
                };
                var select_page_data = phpData(data);
                methods.drawBody(select_page_data, rowsCount,self,that_grid);
                self.find(".pagenationDiv").remove();
                self.append(methods.pagination(select_page_data[1], rowsCount, that_grid,self));
                methods.selectPage(self, rowsCount, gridarray);
                methods.selectNext(self, rowsCount, gridarray);
                methods.selectPrev(self, rowsCount, gridarray);
                methods.selectFirst(self, rowsCount, gridarray);
                methods.selectLast(self, rowsCount, gridarray);
            });
        },
    };
    $.fn.bePhpJsGrid = function (method) {
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        } else {
            $.error('Unknown method ' + method);
        }
    };
})(jQuery);

function getOrder(self) {
    var ord_arrray = [];
    var order_select_page;
    self.find('.be_grid_header').each(function () {
        if ($(this).attr("order") == "ASC" || $(this).attr("order") == "DESC") {
            ord_arrray.push([$(this).attr("order"), $(this).text()]);
        }

    });

    if (ord_arrray.length == 0) {
        order_select_page = "none";
    } else {
        order_select_page = [];
        for (var t = 0; t < ord_arrray.length; t++) {
            order_select_page.push(
                {"name": ord_arrray[t][1], "order": ord_arrray[t][0]}
            );
        }
    }

    return order_select_page;
}

function search(self) {
    var d = [];
    var arr = [];
    self.find('.be_grid_input').each(function () {
        if ($(this).attr("aaa") == "date_range") {
            var date_range_array = [];
            if (d.length < 3) {
                d.push($(this).val());
                if (d.length == 2) {
                    arr.push(d);
                    d = [];
                }
            }
        } else if ($(this).attr("aaa") == "num_range") {
            if (d.length < 3) {
                d.push($(this).val());
                if (d.length == 2) {
                    if (d[0] != "" && d[1] != "") {
                        d[0] = Number(d[0]) - 1;
                        d[1] = Number(d[1]) + 1;
                    }
                    arr.push(d);
                    d = [];
                }
            }
        } else {
            arr.push($(this).val());
        }
    });
    return arr;
}



