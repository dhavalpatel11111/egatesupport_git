<?php
// DB config
$servername = "localhost";
$username = "myname";
$password = "1111111";
$dbname = "wordpress";

// JS POST //
$conn = new mysqli($servername, $username, $password, $dbname);
if($conn->connect_errno) {
    echo "Error to connect Db,Wrong dates";
}else{
    if (count($_POST) == 2) {
        $on_home = $_POST['on_home'];
        $table_name = $_POST['table_name'];
        $query_dates_for_select = "SELECT ";

        for ($o = 0; $o < count($on_home); $o++) {
            $query_dates_for_select .= $on_home[$o] . ",";
        }

        $query_dates_for_select = substr($query_dates_for_select, 0, -1);
        $query_dates_for_select .= " FROM " . $table_name;
//echo $query_dates_for_select;
        $sql_3 = $query_dates_for_select;
        $result_dates_for_select = $conn->query($sql_3);
        $answer = array();
        if ($result_dates_for_select->num_rows > 0) {
            $i = 0;
            while ($row = $result_dates_for_select->fetch_assoc()) {
                $answer[0][$i] = $row;
                $i++;
            }
            echo json_encode($answer);
        } else {
            echo "0";
        }

    } else {
        $page = $_POST['page'];
        $on_home = $_POST['on_home'];
        $table_name = $_POST['table_name'];
        $params = $_POST['params'];
        if ($_POST['ordering'] != "none") {
            $ordering = $_POST['ordering'];
        } else {
            $ordering = Array();
        }

        $limit = $page * $on_home - $on_home;

        $query_max_num_range = "SELECT ";
        $query_min_num_range = "SELECT ";

        for ($o = 0; $o < count($params); $o++) {
            $query_max_num_range .= " MAX(" . $params[$o]["name"] . "),";
            $query_min_num_range .= " MIN(" . $params[$o]["name"] . ") ,";
//    $query_dates_for_select .= $params[$o]["name"] . ",";
        }

        $query_max_num_range = substr($query_max_num_range, 0, -1);
        $query_min_num_range = substr($query_min_num_range, 0, -1);
//$query_dates_for_select = substr($query_dates_for_select,0,-1);


        $query = "";
        $query_c = "";
        $query .= "SELECT ";
        $query_c .= "SELECT count(id) ";
        for ($i = 0; $i < count($params); $i++) {
            $query .= "`" . $params[$i]["name"] . "`";
            if ($i < count($params) - 1) {
                $query .= ", ";
            } else {
                $query .= " ";
            }
        }
        $query .= "FROM `" . $table_name . "` WHERE 1=1 ";
        $query_c .= "AS total FROM `" . $table_name . "` WHERE 1=1 ";
        for ($i = 0; $i < count($params); $i++) {
            if ($params[$i]["value"] != "") {
//        $query .= "AND `" . $params[$i]["name"] . "`";
//        $query_c .= "AND `" . $params[$i]["name"] . "`";
                switch ($params[$i]["type"]) {
                    case "number":
                        $query .= "AND `" . $params[$i]["name"] . "`";
                        $query_c .= "AND `" . $params[$i]["name"] . "`";
                        $query .= " = " . $params[$i]["value"] . " ";
                        $query_c .= " = " . $params[$i]["value"] . " ";
                        break;
                    case "num_range":
                        if ($params[$i]["value"][0] == "" || $params[$i]["value"][1] == "") {
                            if ($params[$i]["value"][0] != "") {
                                $query .= " > '" . $params[$i]["value"][0] . "'";
                                $query_c .= " > '" . $params[$i]["value"][0] . "'";
                            } elseif ($params[$i]["value"][1] != "") {
                                if (substr($query, -3) != "AND") {
                                    $query .= "AND `" . $params[$i]["name"] . "`";
                                    $query_c .= "AND `" . $params[$i]["name"] . "`";
                                    $query .= " < '" . $params[$i]["value"][1] . "' ";
                                    $query_c .= "` < '" . $params[$i]["value"][1] . "' ";
                                }
                            }
                        } else {
                            $query .= "AND `" . $params[$i]["name"] . "`";
                            $query_c .= "AND `" . $params[$i]["name"] . "`";
                            $query .= " > '" . (int)$params[$i]["value"][0] . "' AND " . "`" . $params[$i]["name"] . "` < '" . (int)$params[$i]["value"][1] . "' ";
                            $query_c .= " > '" . (int)$params[$i]["value"][0] . "' AND " . "`" . $params[$i]["name"] . "` < '" . (int)$params[$i]["value"][1] . "' ";
                        }
                        break;
                    case "date":
                        $query .= "AND `" . $params[$i]["name"] . "`";
                        $query_c .= "AND `" . $params[$i]["name"] . "`";
                        $query .= " = '" . $params[$i]["value"] . "' ";
                        $query_c .= " = '" . $params[$i]["value"] . "' ";
                        break;
                    case "date_range":
                        if ($params[$i]["value"][0] == "" || $params[$i]["value"][1] == "") {
                            if ($params[$i]["value"][0] != "") {
                                $query .= "AND `" . $params[$i]["name"] . "`";
                                $query_c .= "AND `" . $params[$i]["name"] . "`";
                                $query .= " > '" . $params[$i]["value"][0] . "'";
                                $query_c .= " > '" . $params[$i]["value"][0] . "'";
                            } elseif ($params[$i]["value"][1] != "") {
                                if (substr($query, -3) != "AND") {
                                    $query .= "AND `" . $params[$i]["name"] . "`";
                                    $query_c .= "AND `" . $params[$i]["name"] . "`";
                                    $query .= " < '" . $params[$i]["value"][1] . "' ";
                                    $query_c .= "` < '" . $params[$i]["value"][1] . "' ";
                                }
                            }
                        } else {
                            $query .= "AND `" . $params[$i]["name"] . "`";
                            $query_c .= "AND `" . $params[$i]["name"] . "`";
                            $query .= " > '" . $params[$i]["value"][0] . "' AND " . "`" . $params[$i]["name"] . "` < '" . $params[$i]["value"][1] . "' ";
                            $query_c .= " > '" . $params[$i]["value"][0] . "' AND " . "`" . $params[$i]["name"] . "` < '" . $params[$i]["value"][1] . "' ";
                        }
                        break;
                    case "text":
                        $query .= "AND `" . $params[$i]["name"] . "`";
                        $query_c .= "AND `" . $params[$i]["name"] . "`";
//                $query .= "AND `" . $params[$i]["name"] . "`";
//                $query_c .= "AND `" . $params[$i]["name"] . "`";
                        $query .= " LIKE '%" . $params[$i]["value"] . "%' ";
                        $query_c .= " LIKE '%" . $params[$i]["value"] . "%' ";
                        break;
                    case "link":
                        $query .= "AND `" . $params[$i]["name"] . "`";
                        $query_c .= "AND `" . $params[$i]["name"] . "`";
//                $query .= "AND `" . $params[$i]["name"] . "`";
//                $query_c .= "AND `" . $params[$i]["name"] . "`";
                        $query .= " LIKE '%" . $params[$i]["value"] . "%' ";
                        $query_c .= " LIKE '%" . $params[$i]["value"] . "%' ";
                        break;
                    case "combo":
                        $query .= "AND `" . $params[$i]["name"] . "`";
                        $query_c .= "AND `" . $params[$i]["name"] . "`";
                        $query .= " = '" . $params[$i]["value"] . "' ";
                        $query_c .= " = '" . $params[$i]["value"] . "' ";
                        break;
                }
            }
        }
        if (!empty($ordering)) {
            $query .= " ORDER BY ";
            for ($i = 0; $i < count($ordering); $i++) {
                $query .= "`" . $ordering[$i]["name"] . "` " . $ordering[$i]["order"];
                if ($i < count($ordering) - 1) {
                    $query .= ", ";
                } else {
                    $query .= " ";
                }
            }
        }
        $query .= " LIMIT $limit, $on_home";
        $query_max_num_range .= " FROM " . $table_name;
        $query_min_num_range .= " FROM " . $table_name;
//$query_dates_for_select .= " FROM " . $table_name;
//echo $query;
//echo $query_max_num_range ;
//echo $query_dates_for_select;
// Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
//echo $query . "<br>";
        $sql = $query;
        $sql_1 = $query_max_num_range;
        $sql_2 = $query_min_num_range;
//$sql_3 = $query_dates_for_select;

        $result = $conn->query($sql);
        $result_max = $conn->query($sql_1);
        $result_min = $conn->query($sql_2);
//$result_dates_for_select = $conn->query($sql_3);

        $answer = Array();
        $answer[0] = Array();
        $answer[2] = Array();
        $answer[3] = Array();
//$answer[4] = Array();
//echo $query_c."<br>";;
        $result_c = $conn->query($query_c);
        $count = $result_c->fetch_assoc();
        $answer[1] = $count['total'];

        if ($result_max->num_rows > 0) {
            $i = 0;
            while ($row = $result_max->fetch_assoc()) {
                $answer[2] = $row;
                $i++;
            }
        }


        if ($result_min->num_rows > 0) {
            $i = 0;
            while ($row = $result_min->fetch_assoc()) {
                $answer[3] = $row;
                $i++;
            }
        }

//if ($result_dates_for_select->num_rows > 0) {
//    $i = 0;
//    while ($row = $result_dates_for_select->fetch_assoc()) {
//       $answer[4][$i] = $row;
//        $i++;
//    }
//
//
//}
//print_r($answer);

        if ($result->num_rows > 0) {
            $i = 0;
            while ($row = $result->fetch_assoc()) {
                $answer[0][$i] = $row;
                $i++;
            }
            echo json_encode($answer);
        } else {
            echo "0";
        }
    }


    $conn->close();
}
